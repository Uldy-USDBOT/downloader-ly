@echo off
echo 🎬 VideoGrab Pro
echo =================
echo.

if not exist node_modules (
    echo Installing dependencies...
    call npm install
)

echo Starting server...
call npm start
pause

const Database = require('./database');

console.log('🔧 Setting up VideoGrab Pro...');

const db = new Database();

setTimeout(() => {
    console.log('✅ Setup complete! You can now run: npm start');
    db.close();
    process.exit(0);
}, 1000);

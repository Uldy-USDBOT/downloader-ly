const express = require('express');
const cors = require('cors');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');
const Database = require('./database');
const cron = require('node-cron');

const app = express();
const db = new Database();
const PORT = process.env.PORT || 3000;

// Active downloads tracking
const activeDownloads = new Map();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Ensure downloads directory exists
const downloadsDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
}

// ==================== API ROUTES ====================

// Get video info
app.post('/api/info', async (req, res) => {
    try {
        const { url } = req.body;
        if (!url) return res.status(400).json({ error: 'URL is required' });

        const ytdlp = spawn('yt-dlp', [
            '--dump-json',
            '--no-download',
            '--no-warnings',
            url
        ]);

        let output = '';
        let errorOutput = '';

        ytdlp.stdout.on('data', (data) => {
            output += data.toString();
        });

        ytdlp.stderr.on('data', (data) => {
            errorOutput += data.toString();
        });

        ytdlp.on('close', (code) => {
            if (code !== 0 || !output) {
                return res.status(500).json({ 
                    error: 'Failed to fetch video info', 
                    details: errorOutput || 'Unknown error' 
                });
            }

            try {
                const info = JSON.parse(output.trim().split('\n')[0]);
                const duration = info.duration ? 
                    new Date(info.duration * 1000).toISOString().substr(14, 5) : 'Unknown';

                // Extract available formats
                const formats = [];
                const seen = new Set();

                if (info.formats) {
                    info.formats.forEach(f => {
                        if (f.vcodec !== 'none' && f.acodec !== 'none') {
                            const height = f.height || 0;
                            const key = `mp4-${height}`;
                            if (!seen.has(key) && height >= 144) {
                                seen.add(key);
                                formats.push({
                                    format_id: key,
                                    label: `MP4 ${height}p`,
                                    height: height,
                                    type: 'video'
                                });
                            }
                        }
                    });
                }

                // Add audio formats
                formats.push(
                    { format_id: 'mp3-320', label: 'MP3 320kbps', type: 'audio' },
                    { format_id: 'mp3-128', label: 'MP3 128kbps', type: 'audio' }
                );

                // Sort video formats by height desc
                formats.sort((a, b) => {
                    if (a.type === 'audio' && b.type === 'video') return 1;
                    if (a.type === 'video' && b.type === 'audio') return -1;
                    return (b.height || 0) - (a.height || 0);
                });

                res.json({
                    success: true,
                    data: {
                        id: info.id,
                        title: info.title || 'Unknown',
                        author: info.uploader || info.channel || 'Unknown',
                        thumbnail: info.thumbnail || `https://img.youtube.com/vi/${info.id}/maxresdefault.jpg`,
                        duration: duration,
                        description: info.description || '',
                        view_count: info.view_count || 0,
                        formats: formats
                    }
                });
            } catch (e) {
                res.status(500).json({ error: 'Failed to parse video info', details: e.message });
            }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start download
app.post('/api/download', async (req, res) => {
    try {
        const { url, format, quality, title, author, thumbnail, duration } = req.body;
        if (!url || !format) {
            return res.status(400).json({ error: 'URL and format are required' });
        }

        // Create download record
        const downloadId = await db.createDownload({
            url, title, author, thumbnail, duration, format, quality
        });

        const isAudio = format === 'mp3';
        const outputTemplate = path.join(downloadsDir, `${downloadId}.%(ext)s`);

        let args = ['--newline', '--no-warnings', '-o', outputTemplate];

        if (isAudio) {
            args.push('-x', '--audio-format', 'mp3', '--audio-quality', quality === '320' ? '0' : '5');
        } else {
            // Video format
            const height = quality || 1080;
            args.push('-f', `bestvideo[height<=${height}][ext=mp4]+bestaudio[ext=m4a]/best[height<=${height}]`);
            args.push('--merge-output-format', 'mp4');
        }

        args.push('--progress', '--no-playlist', url);

        const ytdlp = spawn('yt-dlp', args);
        activeDownloads.set(downloadId, { process: ytdlp, progress: 0 });

        ytdlp.stdout.on('data', async (data) => {
            const line = data.toString();
            const match = line.match(/\[download\]\s+(\d+\.\d+)%/);
            if (match) {
                const progress = Math.round(parseFloat(match[1]));
                activeDownloads.get(downloadId).progress = progress;
                await db.updateProgress(downloadId, progress);
            }
        });

        ytdlp.stderr.on('data', (data) => {
            console.error(`yt-dlp error: ${data}`);
        });

        ytdlp.on('close', async (code) => {
            activeDownloads.delete(downloadId);

            if (code === 0) {
                // Find the downloaded file
                const files = fs.readdirSync(downloadsDir);
                const downloadedFile = files.find(f => f.startsWith(downloadId));

                if (downloadedFile) {
                    const filePath = path.join(downloadsDir, downloadedFile);
                    const stats = fs.statSync(filePath);
                    const fileSize = formatBytes(stats.size);

                    await db.completeDownload(downloadId, filePath, fileSize);
                } else {
                    await db.failDownload(downloadId, 'File not found after download');
                }
            } else {
                await db.failDownload(downloadId, `Download failed with code ${code}`);
            }
        });

        res.json({ success: true, downloadId });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// SSE Progress stream
app.get('/api/progress/:id', async (req, res) => {
    const { id } = req.params;

    res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
    });

    const sendProgress = async () => {
        try {
            const download = await db.getDownload(id);
            if (!download) {
                res.write(`data: ${JSON.stringify({ error: 'Download not found' })}\n\n`);
                res.end();
                return;
            }

            res.write(`data: ${JSON.stringify({
                progress: download.progress,
                status: download.status,
                file_path: download.file_path,
                file_size: download.file_size,
                error: download.error_message
            })}\n\n`);

            if (download.status === 'completed' || download.status === 'failed') {
                res.end();
                return;
            }
        } catch (e) {
            res.write(`data: ${JSON.stringify({ error: e.message })}\n\n`);
        }
    };

    sendProgress();
    const interval = setInterval(sendProgress, 1000);

    req.on('close', () => {
        clearInterval(interval);
    });
});

// Get download history
app.get('/api/downloads', async (req, res) => {
    try {
        const downloads = await db.getAllDownloads(100);
        res.json({ success: true, data: downloads });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Download file
app.get('/api/download/file/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const download = await db.getDownload(id);

        if (!download || !download.file_path) {
            return res.status(404).json({ error: 'File not found' });
        }

        if (!fs.existsSync(download.file_path)) {
            return res.status(404).json({ error: 'File has been deleted' });
        }

        const fileName = `${download.title || 'video'}.${download.format === 'mp3' ? 'mp3' : 'mp4'}`
            .replace(/[^a-zA-Z0-9\u0600-\u06FF\s.-]/g, '_');

        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        res.setHeader('Content-Type', download.format === 'mp3' ? 'audio/mpeg' : 'video/mp4');

        const fileStream = fs.createReadStream(download.file_path);
        fileStream.pipe(res);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete download record
app.delete('/api/downloads/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await db.deleteDownload(id);
        res.json({ success: true, message: 'Download deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get stats
app.get('/api/stats', async (req, res) => {
    try {
        const stats = await db.getStats();
        const downloads = await db.getAllDownloads(1000);

        const mp4Count = downloads.filter(d => d.format === 'mp4').length;
        const mp3Count = downloads.filter(d => d.format === 'mp3').length;

        res.json({
            success: true,
            data: {
                total_downloads: stats ? stats.total_downloads : 0,
                total_mp4: mp4Count,
                total_mp3: mp3Count,
                recent_downloads: downloads.slice(0, 10)
            }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Cleanup old files (runs every day at midnight)
cron.schedule('0 0 * * *', () => {
    console.log('🧹 Running cleanup...');
    const files = fs.readdirSync(downloadsDir);
    const now = Date.now();
    const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days

    files.forEach(file => {
        const filePath = path.join(downloadsDir, file);
        const stats = fs.statSync(filePath);
        if (now - stats.mtime.getTime() > maxAge) {
            fs.unlinkSync(filePath);
            console.log(`🗑️ Deleted old file: ${file}`);
        }
    });
});

// Helper function
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Start server
app.listen(PORT, () => {
    console.log(`
    ╔══════════════════════════════════════════╗
    ║                                          ║
    ║     🎬 VideoGrab Pro Server Running      ║
    ║                                          ║
    ║     📡 URL: http://localhost:${PORT}          ║
    ║                                          ║
    ╚══════════════════════════════════════════╝
    `);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n👋 Shutting down gracefully...');
    db.close();
    process.exit(0);
});

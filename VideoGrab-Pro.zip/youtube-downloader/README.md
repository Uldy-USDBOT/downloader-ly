# 🎬 VideoGrab Pro

## نظام تحميل الفيديوهات الاحترافي

موقع كامل لتحميل الفيديوهات من YouTube ومنصات أخرى مع:
- ✅ واجهة أمامية احترافية (Dark Mode + Glassmorphism)
- ✅ Backend كامل بـ Node.js + Express
- ✅ قاعدة بيانات SQLite لسجل التحميلات
- ✅ شريط تقدم حقيقي أثناء التحميل (SSE)
- ✅ تحميل الفيديوهات بجودات مختلفة (144p إلى 4K)
- ✅ استخراج الصوت بصيغة MP3
- ✅ إحصائيات وتحليلات
- ✅ حذف تلقائي للملفات القديمة (7 أيام)

---

## 📦 المتطلبات

### 1. Node.js (v16+)
```bash
node --version
```

### 2. yt-dlp
```bash
# Windows
winget install yt-dlp

# macOS
brew install yt-dlp

# Linux
sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp
```

### 3. FFmpeg (مطلوب لدمج الصوت والفيديو)
```bash
# Windows
winget install ffmpeg

# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt update && sudo apt install ffmpeg
```

---

## 🚀 التشغيل

### 1. تثبيت التبعيات
```bash
npm install
```

### 2. تشغيل الخادم
```bash
npm start
```

### 3. فتح الموقع
```
http://localhost:3000
```

---

## 📁 هيكل المشروع

```
youtube-downloader/
├── public/
│   └── index.html          # الواجهة الأمامية
├── downloads/               # مجلد الملفات المحملة
├── server.js               # الخادم الرئيسي
├── database.js             # إدارة قاعدة البيانات
├── package.json            # التبعيات
└── database.db             # قاعدة بيانات SQLite (تُنشأ تلقائياً)
```

---

## 🔌 API Endpoints

| Method | Endpoint | الوصف |
|--------|----------|-------|
| POST | /api/info | جلب معلومات الفيديو |
| POST | /api/download | بدء تحميل جديد |
| GET | /api/progress/:id | تقدم التحميل (SSE) |
| GET | /api/downloads | سجل التحميلات |
| GET | /api/download/file/:id | تحميل الملف |
| DELETE | /api/downloads/:id | حذف من السجل |
| GET | /api/stats | الإحصائيات |

---

## 🗄️ قاعدة البيانات

### جدول downloads
| العمود | النوع | الوصف |
|--------|-------|-------|
| id | TEXT | معرف فريد |
| url | TEXT | رابط الفيديو |
| title | TEXT | العنوان |
| author | TEXT | القناة |
| thumbnail | TEXT | صورة المصغرة |
| duration | TEXT | المدة |
| format | TEXT | الصيغة (mp4/mp3) |
| quality | TEXT | الجودة |
| file_path | TEXT | مسار الملف |
| file_size | TEXT | حجم الملف |
| status | TEXT | الحالة |
| progress | INTEGER | نسبة التقدم |
| created_at | DATETIME | تاريخ الإنشاء |

---

## ⚠️ ملاحظات قانونية

- يرجى احترام حقوق الملكية الفكرية
- لا تستخدم لتحميل محتوى محمي بحقوق الطبع
- يجب امتلاك حقوق المشاهدة أو التحميل للمحتوى

---

## 🛠️ التطوير

```bash
# وضع التطوير مع إعادة التشغيل التلقائي
npm run dev
```

---

## 📄 الترخيص

MIT License - استخدمه كما تشاء!

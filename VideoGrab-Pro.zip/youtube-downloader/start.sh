#!/bin/bash
echo "🎬 VideoGrab Pro"
echo "================="
echo ""

if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

echo "Starting server..."
npm start

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, 'database.db');

class Database {
    constructor() {
        this.db = new sqlite3.Database(DB_PATH, (err) => {
            if (err) {
                console.error('❌ خطأ في فتح قاعدة البيانات:', err.message);
            } else {
                console.log('✅ تم الاتصال بقاعدة البيانات SQLite');
                this.initTables();
            }
        });
    }

    initTables() {
        this.db.run(`
            CREATE TABLE IF NOT EXISTS downloads (
                id TEXT PRIMARY KEY,
                url TEXT NOT NULL,
                title TEXT,
                author TEXT,
                thumbnail TEXT,
                duration TEXT,
                format TEXT NOT NULL,
                quality TEXT,
                file_path TEXT,
                file_size TEXT,
                status TEXT DEFAULT 'pending',
                progress INTEGER DEFAULT 0,
                error_message TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME
            )
        `);

        this.db.run(`
            CREATE TABLE IF NOT EXISTS stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                total_downloads INTEGER DEFAULT 0,
                total_mp4 INTEGER DEFAULT 0,
                total_mp3 INTEGER DEFAULT 0,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Insert initial stats if not exists
        this.db.get("SELECT * FROM stats WHERE id = 1", (err, row) => {
            if (!row) {
                this.db.run("INSERT INTO stats (id, total_downloads, total_mp4, total_mp3) VALUES (1, 0, 0, 0)");
            }
        });
    }

    createDownload(data) {
        return new Promise((resolve, reject) => {
            const id = uuidv4();
            const { url, title, author, thumbnail, duration, format, quality } = data;

            this.db.run(
                `INSERT INTO downloads (id, url, title, author, thumbnail, duration, format, quality, status, progress)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0)`,
                [id, url, title, author, thumbnail, duration, format, quality],
                function(err) {
                    if (err) reject(err);
                    else resolve(id);
                }
            );
        });
    }

    updateProgress(id, progress) {
        return new Promise((resolve, reject) => {
            this.db.run(
                "UPDATE downloads SET progress = ? WHERE id = ?",
                [progress, id],
                (err) => {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    completeDownload(id, filePath, fileSize) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `UPDATE downloads SET status = 'completed', file_path = ?, file_size = ?, completed_at = CURRENT_TIMESTAMP, progress = 100 WHERE id = ?`,
                [filePath, fileSize, id],
                (err) => {
                    if (err) reject(err);
                    else {
                        this.db.run("UPDATE stats SET total_downloads = total_downloads + 1, updated_at = CURRENT_TIMESTAMP WHERE id = 1");
                        resolve();
                    }
                }
            );
        });
    }

    failDownload(id, errorMessage) {
        return new Promise((resolve, reject) => {
            this.db.run(
                "UPDATE downloads SET status = 'failed', error_message = ? WHERE id = ?",
                [errorMessage, id],
                (err) => {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    getDownload(id) {
        return new Promise((resolve, reject) => {
            this.db.get("SELECT * FROM downloads WHERE id = ?", [id], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    getAllDownloads(limit = 50) {
        return new Promise((resolve, reject) => {
            this.db.all(
                `SELECT * FROM downloads ORDER BY created_at DESC LIMIT ?`,
                [limit],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    }

    getStats() {
        return new Promise((resolve, reject) => {
            this.db.get("SELECT * FROM stats WHERE id = 1", (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    deleteDownload(id) {
        return new Promise((resolve, reject) => {
            this.db.get("SELECT file_path FROM downloads WHERE id = ?", [id], (err, row) => {
                if (err) reject(err);
                else {
                    if (row && row.file_path) {
                        const fs = require('fs');
                        if (fs.existsSync(row.file_path)) {
                            fs.unlinkSync(row.file_path);
                        }
                    }
                    this.db.run("DELETE FROM downloads WHERE id = ?", [id], (err) => {
                        if (err) reject(err);
                        else resolve();
                    });
                }
            });
        });
    }

    close() {
        this.db.close((err) => {
            if (err) console.error(err.message);
            else console.log('🔒 تم إغلاق قاعدة البيانات');
        });
    }
}

module.exports = Database;
